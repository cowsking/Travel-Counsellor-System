package com.example.TravelCounsellingSystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.SparseBooleanArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import multiview.Fruit;
import multiview.FruitAdapter;

public class Select2 extends AppCompatActivity {

    private List<Fruit> fruitList = new ArrayList<Fruit>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select2_layout);
        Intent intent=getIntent();
        String[] Select1Info=intent.getStringArrayExtra("SelectInfo");

        initFruits();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        StaggeredGridLayoutManager layoutManager = new
                StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setPadding(0,0,0,0);
        SparseBooleanArray clciked = new SparseBooleanArray(fruitList.size());
        FruitAdapter adapter = new FruitAdapter(fruitList,clciked );
        recyclerView.setAdapter(adapter);
    }

    private void initFruits() {
        Fruit London = new Fruit(getRandomLengthName("London"), R.drawable.a1);
        fruitList.add(London);
        Fruit Liverpool = new Fruit(getRandomLengthName("Liverpool"), R.drawable.a2);
        fruitList.add(Liverpool);
        Fruit Manchester = new Fruit(getRandomLengthName("Manchester"), R.drawable.a3);
        fruitList.add(Manchester);
        Fruit Birmingham = new Fruit(getRandomLengthName("Birmingham"), R.drawable.a4);
        fruitList.add(Birmingham);
        Fruit Leeds = new Fruit(getRandomLengthName("Leeds"), R.drawable.a5);
        fruitList.add(Leeds);
        Fruit Bristol = new Fruit(getRandomLengthName("Bristol"), R.drawable.a6);
        fruitList.add(Bristol);
        Fruit Brighton = new Fruit(getRandomLengthName("Brighton"), R.drawable.a7);
        fruitList.add(Brighton);
        Fruit Plymouth = new Fruit(getRandomLengthName("Plymouth"), R.drawable.a8);
        fruitList.add(Plymouth);
        Fruit York = new Fruit(getRandomLengthName("York"), R.drawable.a9);
        fruitList.add(York);
        Fruit Sheffield = new Fruit(getRandomLengthName("Sheffield"), R.drawable.a10);
        fruitList.add(Sheffield);
        Fruit Newcastle = new Fruit(getRandomLengthName("Newcastle"), R.drawable.a11);
        fruitList.add(Newcastle);
        Fruit Nottingham = new Fruit(getRandomLengthName("Nottingham"), R.drawable.a12);
        fruitList.add(Nottingham);
        Fruit Oxford = new Fruit(getRandomLengthName("Oxford"), R.drawable.a13);
        fruitList.add(Oxford);
        Fruit Bath = new Fruit(getRandomLengthName("Bath"), R.drawable.a14);
        fruitList.add(Bath);
        Fruit Norwich = new Fruit(getRandomLengthName("Norwich"), R.drawable.a15);
        fruitList.add(Norwich);
        Fruit Isle = new Fruit(getRandomLengthName("Isle of Wight"), R.drawable.a16);
        fruitList.add(Isle);
        Fruit Cambridge = new Fruit(getRandomLengthName("Cambridge"), R.drawable.a17);
        fruitList.add(Cambridge);
        Fruit Southampton = new Fruit(getRandomLengthName("Southampton"), R.drawable.a18);
        fruitList.add(Southampton);
        Fruit Canterbury = new Fruit(getRandomLengthName("Canterbury"), R.drawable.a19);
        fruitList.add(Canterbury);
        Fruit Leicester = new Fruit(getRandomLengthName("Leicester"), R.drawable.a20);
        fruitList.add(Leicester);
        Fruit submit = new Fruit(getRandomLengthName(""), R.drawable.submit);
        fruitList.add(submit);
    }

    private String getRandomLengthName(String name) {
        StringBuilder builder = new StringBuilder();
        builder.append(name);
        return builder.toString();
    }

//    private String[] sortCities(){
//        String[] sortedCity;
//        return sortedCity;
//    }


}